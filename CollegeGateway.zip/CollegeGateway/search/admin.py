from django.contrib import admin
from .models import College

admin.site.register(College)
