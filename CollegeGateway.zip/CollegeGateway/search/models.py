from django.db import models

class User(models.Model):
    name = models.CharField(max_length=25)
    mail = models.CharField(max_length=50)
    password = models.CharField(max_length=50)


class Profile(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    category = models.IntegerField(default=0)
    home_state = models.CharField(max_length=50)
    mains_rank = models.IntegerField()
    advanced_rank = models.IntegerField(default=0)

class College(models.Model):
    c_name = models.CharField(max_length=50)
    c_locality = models.CharField(max_length=25)
    c_state = models.CharField(max_length=25)
    c_country = models.CharField(max_length=25)
    c_pincode = models.IntegerField()
    c_link = models.CharField(max_length=100)
    c_img = models.CharField(max_length=500)


class Department(models.Model):
    college = models.ForeignKey(College, on_delete=models.CASCADE)
    d_name = models.CharField(max_length=25)
    g_op_rank = models.IntegerField()
    g_cl_rank = models.IntegerField()
    obc_op_rank = models.IntegerField()
    obc_cl_rank = models.IntegerField()
    sc_op_rank = models.IntegerField()
    sc_cl_rank = models.IntegerField()
    st_op_rank = models.IntegerField()
    st_cl_rank = models.IntegerField()
    hm_g_op_rank = models.IntegerField()
    hm_g_cl_rank = models.IntegerField()
    hm_obc_op_rank = models.IntegerField()
    hm_obc_cl_rank = models.IntegerField()
    hm_sc_op_rank = models.IntegerField()
    hm_sc_cl_rank = models.IntegerField()
    hm_st_op_rank = models.IntegerField()
    hm_st_cl_rank = models.IntegerField()